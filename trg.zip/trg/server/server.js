const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const basicAuth = require('express-basic-auth');

const app = express();
const PORT = 8000;

const feedbackFile = path.join(__dirname, 'feedback.json');

app.use(bodyParser.json());

// Basic auth for admin routes
app.use('/admin', basicAuth({
  users: { 'admin': 'password123' }, // change password as needed
  challenge: true,
  unauthorizedResponse: (req) => 'Unauthorized'
}));

// Serve admin page
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin.html'));
});

// Serve admin.html explicitly for /admin.html path
app.get('/admin.html', (req, res) => {
  res.redirect('/admin');
});

app.use(express.static(path.join(__dirname, '..'))); // serve frontend files

// Endpoint to receive feedback data
app.post('/feedback', (req, res) => {
  const feedback = req.body;
  if (!feedback || !feedback.role || !feedback.district || !feedback.constituency || !feedback.name || !feedback.rating || !feedback.feedback) {
    return res.status(400).json({ error: 'Missing required feedback fields' });
  }

  // Read existing feedbacks
  let feedbacks = [];
  if (fs.existsSync(feedbackFile)) {
    const data = fs.readFileSync(feedbackFile);
    feedbacks = JSON.parse(data);
  }

  feedbacks.push(feedback);

  fs.writeFileSync(feedbackFile, JSON.stringify(feedbacks, null, 2));

  res.json({ message: 'Feedback received' });
});

// Endpoint to get all feedbacks (protected)
app.get('/feedbacks', basicAuth({
  users: { 'admin': 'password123' },
  challenge: true,
  unauthorizedResponse: (req) => 'Unauthorized'
}), (req, res) => {
  if (fs.existsSync(feedbackFile)) {
    const data = fs.readFileSync(feedbackFile);
    const feedbacks = JSON.parse(data);
    res.json(feedbacks);
  } else {
    res.json([]);
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
